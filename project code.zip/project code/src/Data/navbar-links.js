export const NavbarLinks = [
  {
    title: "Home",
    path: "/",
  },
  {
    title: "About Us",
    path: "/about",
  },
  {
    title: "Find Jobs",
    path: "/job",
  },
  {
    title: "Blog",
   path:"/blog",
  },
 
  {
    title: "Contact Us",
    path: "/contact",
  },
];
