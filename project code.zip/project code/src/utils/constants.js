export const ACCOUNT_TYPE = {
  APPLICANT: "Applicant",
  RECRUITER: "Recruiter",
}
